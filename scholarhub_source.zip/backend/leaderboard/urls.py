from django.urls import path
from . import views

urlpatterns = [
    path('', views.LeaderboardView.as_view(), name='leaderboard'),
    path('me/', views.MyStatsView.as_view(), name='my-stats'),
]
